import Hero from "@/components/Hero";
import ProblemSection from "@/components/ProblemSection";
import MechanismSection from "@/components/MechanismSection";
import ProductPreviewCarousel from "@/components/ProductPreviewCarousel";
import ContentOrganization from "@/components/ContentOrganization";
import BenefitsGrid from "@/components/BenefitsGrid";
import MidCta from "@/components/MidCta";
import AudienceChecklist from "@/components/AudienceChecklist";
import MainProduct from "@/components/MainProduct";
import BonusGrid from "@/components/BonusGrid";
import ComparisonSection from "@/components/ComparisonSection";
import Testimonials from "@/components/Testimonials";
import StackSection from "@/components/StackSection";
import PositioningSection from "@/components/PositioningSection";
import OfferSection from "@/components/OfferSection";
import FaqAccordion from "@/components/FaqAccordion";
import FinalCta from "@/components/FinalCta";
import Footer from "@/components/Footer";
import StickyMobileCta from "@/components/StickyMobileCta";

export default function Home() {
  return (
    <>
      <main>
        <Hero />
        <ProblemSection />
        <MechanismSection />
        <ProductPreviewCarousel />
        <ContentOrganization />
        <BenefitsGrid />
        <MidCta />
        <AudienceChecklist />
        <MainProduct />
        <BonusGrid />
        <ComparisonSection />
        <Testimonials />
        <StackSection />
        <PositioningSection />
        <OfferSection />
        <FaqAccordion />
        <FinalCta />
      </main>
      <Footer />
      <StickyMobileCta />
    </>
  );
}
