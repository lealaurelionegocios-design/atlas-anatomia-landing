import type { Metadata } from "next";
import "@fontsource-variable/inter";
import "./globals.css";

export const metadata: Metadata = {
  title:
    "Atlas Visual de Anatomia de Cabeça e Pescoço para Odontologia",
  description:
    "80 Pranchas Anatômicas + 20 Mapas Mentais para visualizar, localizar e conectar as principais estruturas de Cabeça e Pescoço estudadas em Odontologia.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body className="font-sans">{children}</body>
    </html>
  );
}
