# Atlas Visual de Anatomia de Cabeça e Pescoço — Landing Page

Landing page de conversão para o produto digital **Atlas Visual de Anatomia de
Cabeça e Pescoço para Odontologia** (80 pranchas + 20 mapas mentais).

## Stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS
- Componentes React reutilizáveis, sem dependências externas de UI

## Rodando localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000.

## Onde editar

- **Textos, preço e slots de imagem:** `data/offer.ts` — arquivo único com
  toda a copy da página. Não é necessário mexer nos componentes para trocar
  texto, preço ou CTA.
- **Link de checkout:** variável `checkoutUrl` em `data/offer.ts`.
- **Depoimentos:** desativados por padrão em `testimonials` (`data/offer.ts`).
  Preencha `items` e mude `enabled` para `true` quando houver feedback real.

## Substituindo os placeholders por imagens reais

Cada imagem da página está definida em `data/offer.ts` como um `ImageSlot`:

```ts
{
  src: "/images/hero-atlas.webp",
  alt: "...",
  fileName: "hero-atlas.webp",
  role: "Mockup principal do hero",
  aspect: "4 / 5",
  exists: false, // ⬅ troque para true quando o arquivo existir
}
```

Passos para publicar uma imagem definitiva:

1. Gere o asset final (mockup, capa, prancha etc.).
2. Salve-o em `public/images/` com o nome exato indicado em `fileName`.
3. No `data/offer.ts`, mude `exists: false` para `exists: true` no slot
   correspondente.
4. O componente `ImagePlaceholder` passa a renderizar a imagem real via
   `next/image` automaticamente — nenhum outro código precisa mudar.

Enquanto `exists` for `false`, a página mostra um placeholder elegante que
preserva a proporção definitiva do layout (nunca um ícone de imagem quebrada).

### Lista de imagens esperadas (`public/images/`)

| Arquivo                  | Função                                          |
| ------------------------ | ------------------------------------------------ |
| hero-atlas.webp          | Mockup principal do hero                          |
| preview-01.webp          | Demonstração — visão geral do atlas               |
| preview-02.webp          | Demonstração — osteologia                         |
| preview-03.webp          | Demonstração — mandíbula                          |
| preview-04.webp          | Demonstração — músculos da mastigação             |
| preview-05.webp          | Demonstração — nervo trigêmeo                     |
| preview-06.webp          | Demonstração — ATM                                |
| preview-07.webp          | Demonstração — vascularização                     |
| preview-08.webp          | Demonstração — mapa mental                        |
| product-index.webp       | Índice visual do atlas                            |
| main-product.webp        | Mockup do produto principal                       |
| bonus-01.webp            | Mapa-Mestre do Nervo Trigêmeo                     |
| bonus-02.webp            | Guia Visual dos Forames do Crânio                 |
| bonus-03.webp            | Mapa Visual dos Músculos da Mastigação             |
| bonus-04.webp            | Checklist para Prova Prática                      |
| traditional-study.webp   | Comparação — estudo tradicional                   |
| atlas-study.webp         | Comparação — atlas visual                         |
| full-stack.webp          | Stack completo / oferta                           |
| final-product.webp       | Mockup do CTA final                               |

## Estrutura de componentes

```
app/
  layout.tsx        # fonte (Inter), metadata
  page.tsx           # monta todas as seções na ordem de conversão
  globals.css
components/
  ui/                # Section, ImagePlaceholder, CtaButton, Eyebrow
  Hero.tsx
  ProblemSection.tsx
  MechanismSection.tsx
  ProductPreviewCarousel.tsx
  ContentOrganization.tsx
  BenefitsGrid.tsx
  MidCta.tsx
  AudienceChecklist.tsx
  MainProduct.tsx
  BonusGrid.tsx
  ComparisonSection.tsx
  Testimonials.tsx   # desativado por padrão
  StackSection.tsx
  PositioningSection.tsx
  OfferSection.tsx   # id="oferta" — âncora de todos os CTAs
  FaqAccordion.tsx
  FinalCta.tsx
  Footer.tsx
  StickyMobileCta.tsx
data/
  offer.ts           # toda a copy, preço e slots de imagem
```

## Order bump (preparado, não publicado)

A estrutura de dados para o order bump **Guia Visual de Anatomia para
Anestesia Odontológica** já está em `data/offer.ts` (`orderBump`), pronta para
ser usada numa seção ou checkout complementar futuro. Ele não aparece na
página principal, conforme especificado.
