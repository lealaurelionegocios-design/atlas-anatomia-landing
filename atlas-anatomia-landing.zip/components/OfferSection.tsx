import { offerSection, product, offerAnchorId } from "@/data/offer";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";
import CtaButton from "@/components/ui/CtaButton";

export default function OfferSection() {
  return (
    <section id={offerAnchorId} className="bg-paper py-16 md:py-24">
      <div className="mx-auto max-w-shell px-6 md:px-10">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-[55fr_45fr] lg:items-center lg:gap-14">
          <ImagePlaceholder slot={offerSection.image} className="shadow-plate" />

          <div className="rounded-plate border border-navy/12 bg-cream p-8 md:p-10">
            <h2 className="text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
              {offerSection.headline}
            </h2>

            <ul className="mt-6 space-y-2 text-[15px] text-navy/90">
              {offerSection.deliverables.map((item, index) => (
                <li key={item} className="flex items-center gap-2">
                  {index > 0 ? (
                    <span aria-hidden className="text-wine">
                      +
                    </span>
                  ) : null}
                  {item}
                </li>
              ))}
            </ul>

            <div className="mt-8 border-t border-navy/10 pt-6">
              <p className="text-[36px] font-semibold text-navy">
                {product.price}
              </p>
              <p className="text-[13px] text-ink/60">
                {product.priceNote} · {product.format}
              </p>
            </div>

            <CtaButton
              label={offerSection.ctaLabel}
              microcopy={offerSection.ctaMicrocopy}
              toCheckout
              className="mt-7"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
