import { testimonials } from "@/data/offer";
import Section from "@/components/ui/Section";

/**
 * Componente de prova social — desativado por padrão (testimonials.enabled em
 * data/offer.ts). Assim que houver depoimentos reais, preencha
 * `testimonials.items` e ative `enabled: true`; o componente já renderiza
 * automaticamente sem precisar tocar na página.
 */
export default function Testimonials() {
  if (!testimonials.enabled || testimonials.items.length === 0) return null;

  return (
    <Section tone="white">
      <h2 className="text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
        O que dizem quem já usa
      </h2>
      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-3">
        {testimonials.items.map((item) => (
          <blockquote
            key={item.name}
            className="rounded-plate border border-navy/12 bg-cream p-6"
          >
            <p className="text-[14px] leading-relaxed text-ink/80">
              “{item.quote}”
            </p>
            <footer className="mt-4 text-[13px] font-medium text-navy">
              {item.name} · {item.course}
            </footer>
          </blockquote>
        ))}
      </div>
    </Section>
  );
}
