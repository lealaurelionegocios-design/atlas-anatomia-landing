import { comparison } from "@/data/offer";
import Section from "@/components/ui/Section";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";

function FlowLine({ steps }: { steps: string[] }) {
  return (
    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[13px] font-medium text-ink/70">
      {steps.map((step, index) => (
        <span key={step} className="flex items-center gap-2">
          {step}
          {index < steps.length - 1 ? (
            <span aria-hidden className="text-navy/30">
              ↓
            </span>
          ) : null}
        </span>
      ))}
    </div>
  );
}

export default function ComparisonSection() {
  return (
    <Section tone="white">
      <h2 className="max-w-measure text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
        {comparison.headline}
      </h2>

      <div className="mt-10 grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-10">
        {/* Estudo tradicional */}
        <div>
          <p className="text-[13px] font-semibold tracking-[0.1em] text-ink/60">
            {comparison.traditional.title}
          </p>
          <div className="mt-3">
            <FlowLine steps={comparison.traditional.flow} />
            <p className="mt-2 text-[13px] italic text-ink/55">
              {comparison.traditional.flowNote}
            </p>
          </div>
          <ImagePlaceholder
            slot={comparison.traditional.image}
            className="mt-5 shadow-plate"
          />
          <ul className="mt-5 space-y-2">
            {comparison.traditional.items.map((item) => (
              <li key={item} className="flex items-start gap-2 text-[14px] text-ink/70">
                <span aria-hidden className="mt-1 text-ink/30">
                  –
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* Atlas visual */}
        <div>
          <p className="text-[13px] font-semibold tracking-[0.1em] text-wine">
            {comparison.atlas.title}
          </p>
          <div className="mt-3">
            <FlowLine steps={comparison.atlas.flow} />
          </div>
          <ImagePlaceholder
            slot={comparison.atlas.image}
            className="mt-5 shadow-plate"
          />
          <ul className="mt-5 space-y-2">
            {comparison.atlas.items.map((item) => (
              <li key={item} className="flex items-start gap-2 text-[14px] text-navy">
                <span aria-hidden className="mt-1 text-wine">
                  ✓
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  );
}
