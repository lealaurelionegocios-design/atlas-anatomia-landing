import { benefits } from "@/data/offer";
import Section from "@/components/ui/Section";

export default function BenefitsGrid() {
  return (
    <Section tone="white">
      <h2 className="max-w-measure text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
        {benefits.headline}
      </h2>

      <div className="mt-10 grid grid-cols-1 gap-x-8 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
        {benefits.items.map((item) => (
          <div key={item.title} className="border-t border-navy/12 pt-4">
            <h3 className="text-[15px] font-semibold text-navy">
              {item.title}
            </h3>
            <p className="mt-2 text-[14px] leading-relaxed text-ink/70">
              {item.description}
            </p>
          </div>
        ))}
      </div>
    </Section>
  );
}
