"use client";

import { useRef } from "react";
import { demonstration } from "@/data/offer";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";
import Eyebrow from "@/components/ui/Eyebrow";

export default function ProductPreviewCarousel() {
  const trackRef = useRef<HTMLDivElement>(null);

  const scrollByCard = (direction: 1 | -1) => {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector<HTMLElement>("[data-slide]");
    const amount = card ? card.offsetWidth + 16 : track.clientWidth * 0.8;
    track.scrollBy({ left: amount * direction, behavior: "smooth" });
  };

  return (
    <section className="bg-navy py-16 text-cream md:py-24">
      <div className="mx-auto max-w-shell px-6 md:px-10">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <Eyebrow tone="cream">{demonstration.eyebrow}</Eyebrow>
            <h2 className="mt-4 max-w-measure text-[24px] font-semibold leading-snug sm:text-[28px]">
              {demonstration.headline}
            </h2>
            <p className="mt-3 max-w-measure-sm text-[15px] leading-relaxed text-cream/75">
              {demonstration.text}
            </p>
          </div>

          <div className="hidden gap-2 sm:flex">
            <button
              type="button"
              onClick={() => scrollByCard(-1)}
              aria-label="Ver prancha anterior"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-cream/25 text-cream transition-colors hover:bg-cream/10"
            >
              ←
            </button>
            <button
              type="button"
              onClick={() => scrollByCard(1)}
              aria-label="Ver próxima prancha"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-cream/25 text-cream transition-colors hover:bg-cream/10"
            >
              →
            </button>
          </div>
        </div>
      </div>

      <div
        ref={trackRef}
        className="no-scrollbar mt-10 flex snap-x-mandatory gap-4 overflow-x-auto px-6 pb-2 md:gap-6 md:px-[calc((100vw-1240px)/2+2.5rem)]"
      >
        {demonstration.slides.map((slide, index) => (
          <div
            key={slide.fileName}
            data-slide
            className="snap-center-child w-[84%] flex-shrink-0 sm:w-[62%] lg:w-[38%]"
          >
            <ImagePlaceholder
              slot={slide}
              className="shadow-plate"
              sizes="(min-width: 1024px) 460px, (min-width: 640px) 62vw, 84vw"
            />
            <p className="mt-3 text-[13px] text-cream/60">
              {String(index + 1).padStart(2, "0")} — {slide.role}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
