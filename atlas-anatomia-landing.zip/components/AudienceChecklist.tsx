import { audience } from "@/data/offer";
import Section from "@/components/ui/Section";

export default function AudienceChecklist() {
  return (
    <Section tone="mist" spacing="tight">
      <h2 className="max-w-measure text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
        {audience.headline}
      </h2>

      <ul className="mt-8 grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
        {audience.items.map((item) => (
          <li key={item} className="flex items-start gap-3 text-[15px] text-ink/85">
            <span aria-hidden className="mt-1 text-wine">
              ✓
            </span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </Section>
  );
}
