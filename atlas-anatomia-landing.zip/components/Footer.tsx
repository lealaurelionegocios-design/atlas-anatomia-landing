import { footer } from "@/data/offer";

export default function Footer() {
  return (
    <footer className="bg-cream pb-24 pt-10 md:pb-10">
      <div className="mx-auto max-w-shell px-6 md:px-10">
        <p className="max-w-measure text-[13px] leading-relaxed text-ink/55">
          {footer.disclaimer}
        </p>
        <nav className="mt-5 flex flex-wrap gap-x-6 gap-y-2">
          {footer.links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-[13px] text-ink/60 underline decoration-ink/20 underline-offset-4 hover:text-ink"
            >
              {link.label}
            </a>
          ))}
        </nav>
      </div>
    </footer>
  );
}
