import { hero, product } from "@/data/offer";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";
import CtaButton from "@/components/ui/CtaButton";
import Eyebrow from "@/components/ui/Eyebrow";

export default function Hero() {
  return (
    <header className="bg-cream pb-14 pt-12 md:pb-20 md:pt-16">
      <div className="mx-auto max-w-shell px-6 md:px-10">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2 lg:items-center lg:gap-16">
          {/* Bloco de texto principal */}
          <div className="order-1 lg:col-start-1 lg:row-start-1">
            <Eyebrow>{hero.eyebrow}</Eyebrow>
            <h1 className="mt-4 max-w-xl text-[28px] font-semibold leading-[1.18] tracking-tight text-navy sm:text-[34px] lg:text-[38px]">
              {hero.headline}
            </h1>
            <p className="mt-5 max-w-measure-sm text-[16px] leading-relaxed text-ink/80">
              {hero.subheadline}
            </p>
          </div>

          {/* Imagem do produto */}
          <div className="relative order-2 lg:col-start-2 lg:row-span-2 lg:row-start-1">
            <div
              aria-hidden
              className="absolute -inset-3 -z-10 rounded-plate border border-wine/25 sm:-inset-5"
            />
            <ImagePlaceholder slot={hero.image} priority className="shadow-plate" />
          </div>

          {/* Pontos rápidos, preço e CTA */}
          <div className="order-3 space-y-7 lg:col-start-1 lg:row-start-2">
            <ul className="grid grid-cols-2 gap-x-6 gap-y-2 border-y border-navy/10 py-5 text-[14px] text-navy/85 sm:grid-cols-4 lg:grid-cols-2">
              {hero.quickPoints.map((point) => (
                <li key={point} className="flex items-baseline gap-2">
                  <span aria-hidden className="text-wine">
                    ·
                  </span>
                  {point}
                </li>
              ))}
            </ul>

            <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-[13px] text-ink/60">{product.priceNote}</p>
                <p className="text-[34px] font-semibold text-navy">
                  {product.price}
                </p>
              </div>
              <CtaButton
                label={hero.ctaLabel}
                microcopy={hero.ctaMicrocopy}
                className="sm:min-w-[280px]"
              />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
