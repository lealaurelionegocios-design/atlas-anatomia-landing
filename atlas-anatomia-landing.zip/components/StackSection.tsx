import { stack } from "@/data/offer";
import Section from "@/components/ui/Section";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";

export default function StackSection() {
  return (
    <Section tone="mist">
      <h2 className="max-w-measure text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
        {stack.headline}
      </h2>

      <div className="mt-10 grid grid-cols-1 gap-10 lg:grid-cols-[60fr_40fr] lg:items-center lg:gap-14">
        <ImagePlaceholder slot={stack.image} className="shadow-plate" />

        <div>
          <p className="text-[15px] font-semibold tracking-wide text-wine">
            {stack.highlight}
          </p>
          <ul className="mt-5 space-y-3 border-t border-navy/10 pt-5">
            {stack.items.map((item) => (
              <li
                key={item}
                className="flex items-start gap-2 text-[15px] text-navy/90"
              >
                <span aria-hidden className="mt-1 text-wine">
                  ·
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  );
}
