import { bonuses } from "@/data/offer";
import Section from "@/components/ui/Section";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";

export default function BonusGrid() {
  return (
    <Section tone="cream">
      <h2 className="max-w-measure text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
        {bonuses.headline}
      </h2>

      <div className="mt-10 grid grid-cols-1 gap-x-10 gap-y-10 sm:grid-cols-2">
        {bonuses.items.map((bonus) => (
          <div key={bonus.name} className="flex flex-col gap-4 sm:flex-row sm:items-start">
            <ImagePlaceholder
              slot={bonus.image}
              className="w-full shadow-plate sm:w-[45%]"
            />
            <div className="sm:flex-1">
              <h3 className="text-[16px] font-semibold text-navy">
                {bonus.name}
              </h3>
              <p className="mt-2 text-[14px] leading-relaxed text-ink/70">
                {bonus.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}
