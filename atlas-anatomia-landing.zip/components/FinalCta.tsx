import { finalCta, product } from "@/data/offer";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";
import CtaButton from "@/components/ui/CtaButton";

export default function FinalCta() {
  return (
    <section className="bg-navy py-16 text-cream md:py-24">
      <div className="mx-auto grid max-w-shell grid-cols-1 items-center gap-10 px-6 md:px-10 lg:grid-cols-2 lg:gap-16">
        <ImagePlaceholder slot={finalCta.image} className="shadow-plate" />

        <div className="text-center lg:text-left">
          <h2 className="mx-auto max-w-measure text-[26px] font-semibold leading-snug sm:text-[30px] lg:mx-0">
            {finalCta.headline}
          </h2>
          <p className="mx-auto mt-4 max-w-measure-sm text-[15px] leading-relaxed text-cream/75 lg:mx-0">
            {finalCta.subheadline}
          </p>
          <p className="mt-6 text-[30px] font-semibold">{product.price}</p>
          <CtaButton
            label={finalCta.ctaLabel}
            variant="onNavy"
            className="mt-6 flex justify-center lg:justify-start"
          />
        </div>
      </div>
    </section>
  );
}
