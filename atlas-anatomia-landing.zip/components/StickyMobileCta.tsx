import { stickyCta, offerAnchorId } from "@/data/offer";

export default function StickyMobileCta() {
  return (
    <div
      className="fixed inset-x-0 bottom-0 z-40 flex items-center justify-between gap-4 border-t border-navy/10 bg-paper/95 px-5 py-3 backdrop-blur md:hidden"
      style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}
    >
      <span className="text-[17px] font-semibold text-navy">
        {stickyCta.price}
      </span>
      <a
        href={`#${offerAnchorId}`}
        className="rounded-plate bg-wine px-5 py-2.5 text-[13px] font-semibold tracking-wide text-cream"
      >
        {stickyCta.ctaLabel}
      </a>
    </div>
  );
}
