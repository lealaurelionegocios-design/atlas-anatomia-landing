import { midCta, product } from "@/data/offer";
import CtaButton from "@/components/ui/CtaButton";

export default function MidCta() {
  return (
    <section className="bg-navy py-14 text-cream md:py-20">
      <div className="mx-auto flex max-w-shell flex-col items-center gap-6 px-6 text-center md:px-10">
        <h2 className="max-w-measure text-[24px] font-semibold leading-snug sm:text-[28px]">
          {midCta.headline}
        </h2>
        <p className="text-[32px] font-semibold">{product.price}</p>
        <p className="-mt-4 text-[13px] text-cream/70">{product.priceNote}</p>
        <CtaButton
          label={midCta.ctaLabel}
          variant="onNavy"
          className="w-full sm:w-auto"
        />
      </div>
    </section>
  );
}
