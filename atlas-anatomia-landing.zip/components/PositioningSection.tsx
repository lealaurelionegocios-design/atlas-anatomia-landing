import { positioning } from "@/data/offer";
import Section from "@/components/ui/Section";

export default function PositioningSection() {
  return (
    <Section tone="cream" spacing="tight">
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_1fr] lg:items-center lg:gap-16">
        <div>
          <h2 className="max-w-measure text-[22px] font-semibold leading-snug text-navy sm:text-[26px]">
            {positioning.headline}
          </h2>
          <p className="mt-4 max-w-measure-sm text-[15px] leading-relaxed text-ink/75">
            {positioning.text}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-x-2 gap-y-3 lg:justify-end">
          {positioning.flow.map((step, index) => (
            <span key={step} className="flex items-center gap-2">
              <span className="rounded-plate border border-navy/15 bg-paper px-4 py-2 text-[13px] font-medium text-navy">
                {step}
              </span>
              {index < positioning.flow.length - 1 ? (
                <span aria-hidden className="text-navy/30">
                  →
                </span>
              ) : null}
            </span>
          ))}
        </div>
      </div>
    </Section>
  );
}
