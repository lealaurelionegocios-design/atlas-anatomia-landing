import { problem } from "@/data/offer";
import Section from "@/components/ui/Section";

export default function ProblemSection() {
  return (
    <Section tone="cream" spacing="tight">
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1.2fr_0.8fr] lg:gap-16">
        <div>
          <h2 className="max-w-measure text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
            {problem.headline}
          </h2>
          <div className="mt-5 max-w-measure space-y-4 text-[15px] leading-relaxed text-ink/80">
            {problem.paragraphs.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>
        </div>

        <ul className="grid grid-cols-2 content-start gap-3 self-start lg:pt-2">
          {problem.terms.map((term) => (
            <li
              key={term}
              className="rounded-plate border border-navy/15 bg-paper px-4 py-3 text-center text-[13px] font-semibold tracking-[0.08em] text-navy/80"
            >
              {term}
            </li>
          ))}
        </ul>
      </div>
    </Section>
  );
}
