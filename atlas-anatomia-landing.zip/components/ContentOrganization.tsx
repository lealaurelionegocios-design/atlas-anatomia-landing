import { organization } from "@/data/offer";
import Section from "@/components/ui/Section";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";

export default function ContentOrganization() {
  return (
    <Section tone="cream">
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[55fr_45fr] lg:items-center lg:gap-14">
        <ImagePlaceholder slot={organization.image} className="shadow-plate" />

        <div>
          <h2 className="max-w-measure text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
            {organization.headline}
          </h2>

          <p className="mt-4 inline-block rounded-plate bg-wine/10 px-3 py-1 text-[13px] font-semibold tracking-wide text-wine">
            {organization.highlight}
          </p>

          <dl className="mt-6 divide-y divide-navy/10 border-y border-navy/10">
            {organization.blocks.map((block) => (
              <div
                key={block.title}
                className="flex items-baseline justify-between gap-4 py-3"
              >
                <dt className="text-[14px] font-medium text-navy">
                  {block.title}
                </dt>
                <dd className="whitespace-nowrap text-[13px] text-ink/60">
                  {block.detail}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </Section>
  );
}
