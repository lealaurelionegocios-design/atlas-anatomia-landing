import { mechanism } from "@/data/offer";
import Section from "@/components/ui/Section";

export default function MechanismSection() {
  return (
    <Section tone="mist" spacing="tight">
      <h2 className="max-w-measure text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
        {mechanism.headline}
      </h2>

      <div className="mt-10 flex flex-col gap-4 md:flex-row md:items-stretch md:gap-4">
        {mechanism.steps.map((step, index) => (
          <div
            key={step.label}
            className="flex flex-col items-stretch md:flex-1 md:flex-row md:items-stretch"
          >
            <div className="flex-1 rounded-plate border border-navy/12 bg-paper p-6">
              <p className="text-[13px] font-semibold tracking-[0.1em] text-wine">
                {step.label}
              </p>
              <p className="mt-2 text-[14px] leading-relaxed text-ink/75">
                {step.description}
              </p>
            </div>
            {index < mechanism.steps.length - 1 ? (
              <div
                aria-hidden
                className="flex h-10 flex-shrink-0 items-center justify-center text-navy/30 md:h-auto md:w-8"
              >
                <span className="hidden text-xl md:inline">→</span>
                <span className="text-xl md:hidden">↓</span>
              </div>
            ) : null}
          </div>
        ))}
      </div>

      <p className="mt-8 max-w-measure text-[14px] leading-relaxed text-ink/70">
        {mechanism.closing}
      </p>
    </Section>
  );
}
