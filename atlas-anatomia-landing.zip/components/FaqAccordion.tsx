"use client";

import { useState } from "react";
import { faq } from "@/data/offer";
import Section from "@/components/ui/Section";

export default function FaqAccordion() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <Section tone="cream">
      <h2 className="text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
        Perguntas frequentes
      </h2>

      <div className="mt-8 divide-y divide-navy/12 border-y border-navy/12">
        {faq.map((item, index) => {
          const isOpen = openIndex === index;
          const panelId = `faq-panel-${index}`;
          const buttonId = `faq-button-${index}`;

          return (
            <div key={item.question}>
              <h3>
                <button
                  id={buttonId}
                  type="button"
                  aria-expanded={isOpen}
                  aria-controls={panelId}
                  onClick={() => setOpenIndex(isOpen ? null : index)}
                  className="flex w-full items-center justify-between gap-4 py-5 text-left text-[15px] font-medium text-navy"
                >
                  {item.question}
                  <span
                    aria-hidden
                    className={`shrink-0 text-xl text-navy/50 transition-transform ${
                      isOpen ? "rotate-45" : ""
                    }`}
                  >
                    +
                  </span>
                </button>
              </h3>
              <div
                id={panelId}
                role="region"
                aria-labelledby={buttonId}
                hidden={!isOpen}
                className="max-w-measure pb-5 text-[14px] leading-relaxed text-ink/75"
              >
                {item.answer}
              </div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}
