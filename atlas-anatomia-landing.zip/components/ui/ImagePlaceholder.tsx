import Image from "next/image";
import type { ImageSlot } from "@/data/offer";

type ImagePlaceholderProps = {
  slot: ImageSlot;
  /** Prioriza o carregamento (usar só no hero / above the fold) */
  priority?: boolean;
  className?: string;
  sizes?: string;
};

/**
 * Renderiza a imagem real quando `slot.exists` for true.
 * Enquanto o asset não existir, mostra um placeholder elegante que preserva
 * a proporção definitiva do layout — nunca um ícone de imagem quebrada.
 */
export default function ImagePlaceholder({
  slot,
  priority = false,
  className = "",
  sizes = "(min-width: 1024px) 560px, 100vw",
}: ImagePlaceholderProps) {
  return (
    <div
      className={`relative w-full overflow-hidden rounded-plate ${className}`}
      style={{ aspectRatio: slot.aspect }}
    >
      {slot.exists ? (
        <Image
          src={slot.src}
          alt={slot.alt}
          fill
          priority={priority}
          sizes={sizes}
          className="object-cover"
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-2 border border-dashed border-navy/20 bg-mist/60 px-6 text-center">
          <span className="font-mono text-[11px] tracking-wide text-navy/50">
            {slot.fileName}
          </span>
          <span className="max-w-[28ch] text-sm leading-snug text-navy/70">
            {slot.role}
          </span>
        </div>
      )}
    </div>
  );
}
