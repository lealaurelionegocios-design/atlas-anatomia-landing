export default function Eyebrow({
  children,
  tone = "wine",
}: {
  children: string;
  tone?: "wine" | "cream";
}) {
  return (
    <p
      className={`text-xs font-semibold tracking-[0.14em] ${
        tone === "wine" ? "text-wine" : "text-cream/80"
      }`}
    >
      {children}
    </p>
  );
}
