import { HTMLAttributes, ReactNode } from "react";

type SectionProps = HTMLAttributes<HTMLElement> & {
  children: ReactNode;
  /** Cor de fundo da seção (classe Tailwind completa) */
  tone?: "cream" | "white" | "navy" | "mist";
  /** Espaçamento vertical — 'default' para a maioria, 'tight' para blocos curtos */
  spacing?: "default" | "tight";
  id?: string;
};

const toneClasses: Record<NonNullable<SectionProps["tone"]>, string> = {
  cream: "bg-cream",
  white: "bg-paper",
  navy: "bg-navy text-cream",
  mist: "bg-mist",
};

export default function Section({
  children,
  tone = "cream",
  spacing = "default",
  className = "",
  id,
  ...props
}: SectionProps) {
  const paddingY = spacing === "tight" ? "py-12 md:py-16" : "py-16 md:py-24";
  return (
    <section
      id={id}
      className={`${toneClasses[tone]} ${paddingY} ${className}`}
      {...props}
    >
      <div className="mx-auto max-w-shell px-6 md:px-10">{children}</div>
    </section>
  );
}
