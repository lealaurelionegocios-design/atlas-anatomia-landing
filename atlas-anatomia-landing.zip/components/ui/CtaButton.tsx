import { offerAnchorId, checkoutUrl } from "@/data/offer";

type CtaButtonProps = {
  label: string;
  variant?: "primary" | "onNavy";
  microcopy?: string;
  className?: string;
  /** Se true, aponta para o link de checkout em vez de rolar até a oferta */
  toCheckout?: boolean;
};

export default function CtaButton({
  label,
  variant = "primary",
  microcopy,
  className = "",
  toCheckout = false,
}: CtaButtonProps) {
  const base =
    "inline-flex w-full items-center justify-center rounded-plate px-8 py-4 text-[15px] font-semibold tracking-wide transition-colors sm:w-auto";
  const variants: Record<NonNullable<CtaButtonProps["variant"]>, string> = {
    primary: "bg-wine text-cream hover:bg-wine-dark",
    onNavy: "bg-cream text-navy hover:bg-white",
  };

  return (
    <div className={className}>
      <a
        href={toCheckout ? checkoutUrl : `#${offerAnchorId}`}
        className={`${base} ${variants[variant]}`}
      >
        {label}
      </a>
      {microcopy ? (
        <p
          className={`mt-3 text-center text-xs sm:text-left ${
            variant === "onNavy" ? "text-cream/70" : "text-ink/55"
          }`}
        >
          {microcopy}
        </p>
      ) : null}
    </div>
  );
}
