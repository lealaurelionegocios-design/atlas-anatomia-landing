import { mainProduct } from "@/data/offer";
import Section from "@/components/ui/Section";
import ImagePlaceholder from "@/components/ui/ImagePlaceholder";
import Eyebrow from "@/components/ui/Eyebrow";

export default function MainProduct() {
  return (
    <Section tone="white">
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[55fr_45fr] lg:items-center lg:gap-14">
        <ImagePlaceholder slot={mainProduct.image} className="shadow-plate" />

        <div>
          <Eyebrow>{mainProduct.eyebrow}</Eyebrow>
          <h2 className="mt-4 text-[24px] font-semibold leading-snug text-navy sm:text-[28px]">
            {mainProduct.headline}
          </h2>

          <div className="mt-5 flex flex-wrap gap-3">
            <span className="rounded-plate bg-navy px-4 py-2 text-[13px] font-semibold tracking-wide text-cream">
              {mainProduct.highlightPlates}
            </span>
            <span className="rounded-plate bg-wine px-4 py-2 text-[13px] font-semibold tracking-wide text-cream">
              {mainProduct.highlightMaps}
            </span>
          </div>

          <p className="mt-6 max-w-measure-sm text-[15px] leading-relaxed text-ink/75">
            {mainProduct.text}
          </p>
        </div>
      </div>
    </Section>
  );
}
