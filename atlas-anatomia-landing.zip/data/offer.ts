// =============================================================================
// data/offer.ts
// Fonte única de verdade para textos comerciais, preço e slots de imagem.
// Edite este arquivo para atualizar copy sem tocar nos componentes.
// =============================================================================

export type ImageSlot = {
  /** Caminho final em /public/images/... (ainda não existe fisicamente) */
  src: string;
  /** Texto alternativo para acessibilidade, usado quando a imagem existir */
  alt: string;
  /** Nome do arquivo esperado, mostrado no placeholder */
  fileName: string;
  /** Função da imagem dentro da página, mostrada no placeholder */
  role: string;
  /** Proporção largura/altura, ex: "4 / 5" */
  aspect: string;
  /** Enquanto false, renderiza o placeholder elegante em vez da imagem */
  exists: boolean;
};

const img = (
  fileName: string,
  alt: string,
  role: string,
  aspect: string,
  exists: boolean = false
): ImageSlot => ({
  src: `/images/${fileName}`,
  alt,
  fileName,
  role,
  aspect,
  exists,
});

// -----------------------------------------------------------------------------
// Identidade / preço
// -----------------------------------------------------------------------------

export const product = {
  name: "Atlas Visual de Anatomia de Cabeça e Pescoço para Odontologia",
  shortName: "Atlas Visual de Anatomia de Cabeça e Pescoço",
  price: "R$29,90",
  priceNote: "Pagamento único",
  format: "Produto digital",
  audience: "estudantes de Odontologia",
};

export const stackSummary = {
  plates: "80 Pranchas Anatômicas",
  maps: "20 Mapas Mentais",
  complementary: "4 Materiais Complementares",
  totalResources: "100 RECURSOS VISUAIS",
  totalComplementary: "4 MATERIAIS COMPLEMENTARES",
};

// -----------------------------------------------------------------------------
// Hero
// -----------------------------------------------------------------------------

export const hero = {
  eyebrow: "ANATOMIA VISUAL PARA ESTUDANTES DE ODONTOLOGIA",
  headline:
    "80 Pranchas Anatômicas + 20 Mapas Mentais para visualizar, localizar e conectar as principais estruturas de Cabeça e Pescoço estudadas em Odontologia",
  subheadline:
    "Revise ossos, músculos, nervos, vasos, ATM, cavidade oral e outras estruturas através de um sistema visual criado especialmente para estudantes de Odontologia.",
  quickPoints: [
    stackSummary.plates,
    stackSummary.maps,
    stackSummary.complementary,
    product.format,
  ],
  ctaLabel: "QUERO ACESSAR O ATLAS",
  ctaMicrocopy: "Acesso digital após a confirmação da compra.",
  image: img(
    "hero-atlas.webp",
    "Atlas aberto mostrando pranchas anatômicas e mapa mental sobre estruturas de cabeça e pescoço",
    "Mockup principal: capa do atlas, dispositivo com o atlas aberto, 2–3 pranchas e 1 mapa mental visíveis, com indícios dos bônus",
    "4 / 3",
    true
  ),
};

// -----------------------------------------------------------------------------
// Problema
// -----------------------------------------------------------------------------

export const problem = {
  headline:
    "Você reconhece a estrutura no slide, mas trava quando precisa lembrar onde ela fica ou com o que se relaciona?",
  paragraphs: [
    "Estudar Anatomia de Cabeça e Pescoço não envolve apenas decorar nomes.",
    "Na prova teórica ou prática, você precisa localizar estruturas, diferenciar regiões e entender como nervos, músculos, vasos, ossos e cavidades se relacionam.",
    "Quando tudo é estudado de forma isolada, essas conexões ficam muito mais difíceis de recuperar na revisão.",
  ],
  terms: ["LOCALIZAR", "IDENTIFICAR", "DIFERENCIAR", "RELACIONAR"],
};

// -----------------------------------------------------------------------------
// Mecanismo
// -----------------------------------------------------------------------------

export const mechanism = {
  headline:
    "Em vez de estudar estruturas isoladas, enxergue a anatomia em contexto",
  steps: [
    {
      label: "VISUALIZAR",
      description:
        "Identifique claramente a estrutura através da prancha anatômica.",
    },
    {
      label: "LOCALIZAR",
      description:
        "Entenda onde ela está e quais são suas referências anatômicas.",
    },
    {
      label: "CONECTAR",
      description:
        "Veja como aquela estrutura se relaciona com nervos, músculos, vasos, ossos e regiões próximas.",
    },
  ],
  closing:
    "Depois de cada grande bloco, mapas mentais ajudam a consolidar essas relações para revisão.",
};

// -----------------------------------------------------------------------------
// Demonstração (carrossel)
// -----------------------------------------------------------------------------

export const demonstration = {
  eyebrow: "VEJA POR DENTRO",
  headline: "Veja como o Atlas organiza a Anatomia de Cabeça e Pescoço",
  text: "Explore exemplos de pranchas, relações anatômicas e mapas mentais que fazem parte da experiência de revisão.",
  slides: [
    img(
      "preview-01.webp",
      "Visão geral do Atlas de Anatomia de Cabeça e Pescoço",
      "Slide 1 — visão geral do atlas",
      "1385 / 900",
      true
    ),
    img(
      "preview-02.webp",
      "Prancha de osteologia craniofacial",
      "Slide 2 — prancha de osteologia",
      "1335 / 862",
      true
    ),
    img(
      "preview-03.webp",
      "Mandíbula e acidentes anatômicos",
      "Slide 3 — mandíbula e acidentes anatômicos",
      "1350 / 880",
      true
    ),
    img(
      "preview-04.webp",
      "Músculos da mastigação",
      "Slide 4 — músculos da mastigação",
      "1240 / 890",
      true
    ),
    img(
      "preview-05.webp",
      "Nervo trigêmeo e ramificações",
      "Slide 5 — nervo trigêmeo",
      "1255 / 842",
      true
    ),
    img("preview-06.webp", "Articulação temporomandibular (ATM)", "Slide 6 — ATM", "1340 / 805", true),
    img(
      "preview-07.webp",
      "Vascularização de cabeça e pescoço",
      "Slide 7 — vascularização",
      "1305 / 860",
      true
    ),
    img(
      "preview-08.webp",
      "Mapa mental de revisão",
      "Slide 8 — mapa mental de revisão",
      "1355 / 880",
      true
    ),
  ],
};

// -----------------------------------------------------------------------------
// Organização do atlas
// -----------------------------------------------------------------------------

export const organization = {
  headline:
    "Todo o conteúdo dividido em blocos para você encontrar rapidamente o que precisa revisar",
  image: img(
    "product-index.webp",
    "Índice visual do Atlas dividido por blocos de conteúdo",
    "Índice visual do atlas, mostrando a divisão por blocos",
    "1385 / 900",
    true
  ),
  highlight: "80 PRANCHAS + 20 MAPAS",
  blocks: [
    { title: "Osteologia Craniofacial", detail: "12 pranchas + 3 mapas mentais" },
    { title: "Forames, Fossas e Cavidades", detail: "10 pranchas + 3 mapas mentais" },
    { title: "Músculos", detail: "10 pranchas + 3 mapas mentais" },
    { title: "ATM", detail: "6 pranchas + 1 mapa mental" },
    { title: "Cavidade Oral e Glândulas", detail: "8 pranchas + 2 mapas mentais" },
    { title: "Vascularização e Linfáticos", detail: "10 pranchas + 2 mapas mentais" },
    { title: "Inervação", detail: "16 pranchas + 5 mapas mentais" },
    { title: "Anatomia Topográfica Aplicada", detail: "8 pranchas + 1 mapa mental" },
  ],
};

// -----------------------------------------------------------------------------
// Benefícios
// -----------------------------------------------------------------------------

export const benefits = {
  headline: "Uma forma mais visual de revisar Anatomia de Cabeça e Pescoço",
  items: [
    {
      title: "Localize estruturas com mais facilidade",
      description: "Veja cada elemento dentro de seu contexto anatômico.",
    },
    {
      title: "Entenda relações",
      description: "Conecte nervos, músculos, vasos, ossos e regiões.",
    },
    {
      title: "Revise para provas práticas",
      description: "Utilize as pranchas para reforçar identificação anatômica.",
    },
    {
      title: "Compare estruturas parecidas",
      description: "Visualize diferenças sem depender de vários materiais.",
    },
    {
      title: "Consulte rapidamente",
      description: "Encontre o assunto que precisa revisar sem reler capítulos inteiros.",
    },
    {
      title: "Consolide com mapas mentais",
      description: "Use os mapas para revisar as relações depois das pranchas.",
    },
  ],
};

// -----------------------------------------------------------------------------
// CTA intermediário
// -----------------------------------------------------------------------------

export const midCta = {
  headline: "Comece sua revisão visual de Anatomia de Cabeça e Pescoço",
  ctaLabel: "QUERO ACESSAR O ATLAS",
};

// -----------------------------------------------------------------------------
// Para quem é
// -----------------------------------------------------------------------------

export const audience = {
  headline: "Este Atlas é ideal para você que...",
  items: [
    "estuda Odontologia",
    "está cursando Anatomia de Cabeça e Pescoço",
    "precisa se preparar para prova prática",
    "confunde estruturas parecidas",
    "reconhece uma estrutura isolada, mas se perde no contexto",
    "tem dificuldade para conectar nervos, músculos, vasos e regiões",
    "prefere estudar visualmente",
    "quer um material de consulta recorrente",
  ],
};

// -----------------------------------------------------------------------------
// Produto principal
// -----------------------------------------------------------------------------

export const mainProduct = {
  eyebrow: "PRODUTO PRINCIPAL",
  headline: product.name,
  highlightPlates: "80 PRANCHAS ANATÔMICAS",
  highlightMaps: "20 MAPAS MENTAIS",
  text: "Um sistema visual organizado por regiões e estruturas para facilitar revisão, localização e conexão anatômica.",
  image: img(
    "main-product.webp",
    "Mockup do Atlas mostrando capa, páginas internas, pranchas e mapas mentais",
    "Mockup final: capa, atlas aberto, páginas internas, pranchas e mapas mentais",
    "630 / 550",
    true
  ),
};

// -----------------------------------------------------------------------------
// Bônus
// -----------------------------------------------------------------------------

export const bonuses = {
  headline: "E você ainda recebe 4 materiais complementares",
  items: [
    {
      name: "Mapa-Mestre do Nervo Trigêmeo",
      description:
        "Uma visão visual de V1, V2, V3, principais ramificações e relações importantes para revisão acadêmica.",
      image: img(
        "bonus-01.webp",
        "Mapa-Mestre do Nervo Trigêmeo",
        "Bônus 1 — Mapa-Mestre do Nervo Trigêmeo",
        "415 / 560",
        true
      ),
    },
    {
      name: "Guia Visual dos Forames do Crânio",
      description:
        "Forames organizados por localização e estruturas relacionadas para facilitar diferenciação.",
      image: img(
        "bonus-02.webp",
        "Guia Visual dos Forames do Crânio",
        "Bônus 2 — Guia Visual dos Forames do Crânio",
        "385 / 430",
        true
      ),
    },
    {
      name: "Mapa Visual dos Músculos da Mastigação",
      description:
        "Organização visual dos principais músculos, ações e relações anatômicas.",
      image: img(
        "bonus-03.webp",
        "Mapa Visual dos Músculos da Mastigação",
        "Bônus 3 — Mapa Visual dos Músculos da Mastigação",
        "395 / 435",
        true
      ),
    },
    {
      name: "Checklist para Prova Prática de Anatomia",
      description:
        "Uma ferramenta para conferir, região por região, quais estruturas você já consegue identificar e quais ainda precisa revisar.",
      image: img(
        "bonus-04.webp",
        "Checklist para Prova Prática de Anatomia",
        "Bônus 4 — Checklist para Prova Prática",
        "415 / 480",
        true
      ),
    },
  ],
};

// -----------------------------------------------------------------------------
// Comparação
// -----------------------------------------------------------------------------

export const comparison = {
  headline: "Estruturas isoladas x Anatomia em contexto",
  traditional: {
    title: "ESTUDO TRADICIONAL",
    flow: ["Estrutura", "Nome"],
    flowNote: "Aluno precisa montar sozinho todas as relações.",
    image: img(
      "traditional-study.webp",
      "Representação do estudo tradicional com estruturas isoladas",
      "Estudo fragmentado — estruturas isoladas sem conexão visual",
      "4 / 3",
      true
    ),
    items: [
      "muitas estruturas isoladas",
      "informações espalhadas",
      "difícil visualizar relações",
      "revisão pouco integrada",
    ],
  },
  atlas: {
    title: "ATLAS VISUAL",
    flow: ["Estrutura", "Localização", "Relações", "Mapa Mental"],
    image: img(
      "atlas-study.webp",
      "Representação do estudo com o Atlas Visual conectando estruturas",
      "Anatomia conectada — estruturas relacionadas em contexto",
      "1432 / 943",
      true
    ),
    items: [
      "anatomia contextualizada",
      "estruturas relacionadas",
      "navegação visual",
      "mapas de consolidação",
    ],
  },
};

// -----------------------------------------------------------------------------
// Stack completo
// -----------------------------------------------------------------------------

export const stack = {
  headline: "Veja tudo o que está incluído no seu acesso",
  image: img(
    "full-stack.webp",
    "Todos os itens do Atlas Visual reunidos: pranchas, mapas mentais e materiais complementares",
    "Stack completo — todos os componentes do produto reunidos",
    "4 / 3",
    true
  ),
  highlight: `${stackSummary.totalResources} + ${stackSummary.totalComplementary}`,
  items: [
    "Atlas principal",
    "80 pranchas",
    "20 mapas mentais",
    "Mapa-Mestre do Trigêmeo",
    "Guia dos Forames",
    "Mapa dos Músculos da Mastigação",
    "Checklist para Prova Prática",
  ],
};

// -----------------------------------------------------------------------------
// Posicionamento
// -----------------------------------------------------------------------------

export const positioning = {
  headline: "Não é mais um PDF cheio de texto para você acumular",
  text: "A proposta do Atlas é transformar os principais conteúdos da disciplina em uma experiência visual de consulta e revisão.",
  flow: ["Abra", "Escolha a região", "Visualize", "Localize", "Conecte", "Revise"],
};

// -----------------------------------------------------------------------------
// Oferta
// -----------------------------------------------------------------------------

export const offerSection = {
  headline: "Leve hoje o Atlas Visual de Anatomia de Cabeça e Pescoço",
  image: stack.image,
  deliverables: [
    stackSummary.plates,
    stackSummary.maps,
    stackSummary.complementary,
  ],
  ctaLabel: "QUERO ACESSAR O ATLAS POR R$29,90",
  ctaMicrocopy: "Acesso digital após a confirmação da compra.",
};

// -----------------------------------------------------------------------------
// FAQ
// -----------------------------------------------------------------------------

export const faq = [
  {
    question: "Para quem é esse material?",
    answer:
      "Para estudantes de Odontologia que estão estudando Anatomia de Cabeça e Pescoço e desejam complementar suas revisões com um material visual e organizado.",
  },
  {
    question: "O material substitui minhas aulas ou atlas acadêmico?",
    answer: "Não. Ele funciona como material complementar de estudo e revisão.",
  },
  {
    question: "São exatamente 100 páginas?",
    answer:
      "Não necessariamente. A oferta é composta por 80 pranchas anatômicas e 20 mapas mentais. Cada recurso pode ocupar uma ou mais páginas dependendo da estrutura final.",
  },
  {
    question: "Serve para prova prática?",
    answer:
      "O material foi estruturado para ajudar na revisão visual e identificação de estruturas, podendo complementar a preparação para avaliações práticas.",
  },
  {
    question: "É um produto físico?",
    answer:
      "Não. O produto é digital. Mockups impressos existentes na página são apenas representações visuais.",
  },
  {
    question: "Como recebo?",
    answer:
      "Após a confirmação da compra, são disponibilizadas as instruções para acesso ao material digital.",
  },
  {
    question: "Existe direito de arrependimento?",
    answer:
      "A compra segue as regras aplicáveis às contratações online previstas no Código de Defesa do Consumidor.",
  },
];

// -----------------------------------------------------------------------------
// CTA final
// -----------------------------------------------------------------------------

export const finalCta = {
  image: img(
    "final-product.webp",
    "Mockup final do Atlas Visual de Anatomia de Cabeça e Pescoço",
    "Mockup final para fechamento da página",
    "266 / 350",
    true
  ),
  headline: "Visualize, localize e conecte a Anatomia de Cabeça e Pescoço",
  subheadline: `Tenha ${stackSummary.plates} + ${stackSummary.maps} organizados especialmente para estudantes de Odontologia.`,
  ctaLabel: "QUERO ACESSAR O ATLAS",
};

// -----------------------------------------------------------------------------
// Rodapé
// -----------------------------------------------------------------------------

export const footer = {
  disclaimer:
    "Material exclusivamente educacional e complementar. Não substitui formação acadêmica, orientação docente ou material oficial da instituição de ensino.",
  links: [
    { label: "Política de Privacidade", href: "/politica-de-privacidade" },
    { label: "Termos de Uso", href: "/termos-de-uso" },
  ],
};

// -----------------------------------------------------------------------------
// CTA sticky mobile
// -----------------------------------------------------------------------------

export const stickyCta = {
  price: product.price,
  ctaLabel: "QUERO ACESSAR",
};

// -----------------------------------------------------------------------------
// Order bump (estrutura preparada, não exibido na página principal)
// -----------------------------------------------------------------------------

export const orderBump = {
  name: "Guia Visual de Anatomia para Anestesia Odontológica",
  promise:
    "Entenda visualmente os principais pontos anatômicos relacionados às técnicas anestésicas estudadas em Odontologia.",
  isIndependentOffer: true,
};

// -----------------------------------------------------------------------------
// Depoimentos (desativado por padrão — ativar quando houver feedback real)
// -----------------------------------------------------------------------------

export const testimonials = {
  enabled: false,
  items: [] as { name: string; course: string; quote: string }[],
};

// -----------------------------------------------------------------------------
// Link de checkout — inserir antes de publicar
// -----------------------------------------------------------------------------

export const checkoutUrl = "#";

// -----------------------------------------------------------------------------
// Âncora de CTA (usada por todos os botões para rolar até a oferta)
// -----------------------------------------------------------------------------

export const offerAnchorId = "oferta";
