import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./data/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: "#18344A",
          light: "#24465F",
          dark: "#102432",
        },
        wine: {
          DEFAULT: "#8D3B48",
          light: "#A2505D",
          dark: "#712E38",
        },
        cream: "#F7F5F0",
        paper: "#FFFFFF",
        mist: "#E7E8E6",
        ink: "#1A252B",
        system: {
          bone: "#C7BEA8",
          muscle: "#B65C56",
          nerve: "#C99A3A",
          artery: "#A73B34",
          vein: "#33628F",
          gland: "#5C8768",
        },
      },
      fontFamily: {
        sans: [
          "Inter Variable",
          "ui-sans-serif",
          "system-ui",
          "sans-serif",
        ],
      },
      maxWidth: {
        shell: "1240px",
        measure: "660px",
        "measure-sm": "560px",
      },
      boxShadow: {
        plate: "0 1px 2px rgba(24, 52, 74, 0.06), 0 12px 32px -16px rgba(24, 52, 74, 0.18)",
      },
      borderRadius: {
        plate: "6px",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s cubic-bezier(0.22, 1, 0.36, 1) both",
      },
    },
  },
  plugins: [],
};

export default config;
